import Image from "next/image";

export default function Home() {
  return (
    <div className="flex flex-col flex-1 items-center justify-center bg-zinc-50 font-sans dark:bg-black">
      <main className="flex flex-1 w-full max-w-3xl flex-col items-center justify-between py-4 px-16 bg-white dark:bg-black sm:items-start">
    
      
     
      </main>
    </div>
     
  );
}


// import FriendsCard from "@/components/FriendsCard";

// export default async function Home() {
//   const res = await fetch("http://localhost:3000/data.json")
//   const FriendsData = await res.json()

//   return (
//     <div className=" container pb-[60px]">
//       <h1 className="text-24 font-semibold pb-[20px]">Your Friends</h1>
//       <main className=" ">
        
//         <div className="grid grid-cols-4 gap-4">
//           {FriendsData.map(data => (
//             <FriendsCard key={data.id} data={data} />
//           ))}
//         </div>

//       </main>
//     </div>
//   );
// }