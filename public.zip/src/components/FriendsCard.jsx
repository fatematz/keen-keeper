

const FriendsCard=({data}) => {
    const {name, picture, days_since_contact, status} = data
    return (
        <div className=" shadow-2xl border-2 border-gray-100 p-5 rounded-[24px] 
        ">
        <div className=" text-center space-y-2">
            <div className="flex justify-center ">
                <img className="rounded-full" src={picture} alt="" />
            </div>

            <div className="">
            <h1> {name} </h1>
            </div>

            <div className="">
            <p> {days_since_contact}d ago </p>
            </div>
            
            <div className="">
                <p> {status} </p>
            </div>
            </div>
            </div>
    );
};

export default FriendsCard;